/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_boolean.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 14:27:48 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 14:27:51 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_BOOLEAN_H
# define FT_BOOLEAN_H

# include <unistd.h>

// Definition of the custom boolean type
typedef enum a_bool{
	false = 0, // Represents false value
	true = 1,  // Represents true value
}	t_bool;

# define FALSE false   // Preprocessor macro for false value
# define TRUE true     // Preprocessor macro for true value
# define EVEN(number) (number % 2 == 0)   // Preprocessor macro to check if a number is even
# define EVEN_MSG "I have an even number of arguments.\n"   // Message for even number of arguments
# define ODD_MSG "I have an odd number of arguments.\n"     // Message for odd number of arguments
# define SUCCESS 0     // Success return code

#endif // FT_BOOLEAN_
