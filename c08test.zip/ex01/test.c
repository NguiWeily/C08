#include "ft_boolean.h"

void ft_putstr(char *str)
{
	while (*str) // Loop through the string until reaching the null terminator
		write(1, str++, 1); // Write each character to the standard output
}

t_bool ft_is_even(int nbr)
{
	return ((EVEN(nbr)) ? TRUE : FALSE); // Check if the number is even using the EVEN macro and return the corresponding boolean value
}

int main(int argc, char **argv)
{
	(void)argv; // Silence the unused parameter warning for argv
	if (ft_is_even(argc - 1) == TRUE) // Check if the number of arguments (excluding the program name) is even
		ft_putstr(EVEN_MSG); // If even, display the even message
	else
		ft_putstr(ODD_MSG); // If odd, display the odd message
	return (SUCCESS); // Return the success status code
}

