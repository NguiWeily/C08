/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_abs.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 13:53:35 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 13:53:38 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_ABS_H
# define FT_ABS_H

// Header guard to prevent multiple inclusions of the header file

// Macro definition for absolute value
# define ABS(Value) (Value < 0 ? -Value : Value)

#endif
