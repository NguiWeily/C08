#include <stdio.h>

#include "ft_abs.h"

// Include necessary headers

int main(void)
{
	int index;

	// Declare the index variable

	index = -5;

	// Loop from -5 to 4 (inclusive)
	while (index < 5)
	{
		printf("macros::abs(%d) = %d\n", index, ABS(index));

		// Print the value and its absolute value using the ABS macro

		index++; // Increment the index
	}
}

