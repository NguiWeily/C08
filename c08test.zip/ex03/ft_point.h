/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_point.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 14:03:58 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 14:04:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_POINT_H
# define FT_POINT_H

// Header guard to prevent multiple inclusions of the header file

// Define the structure type for representing a point
typedef struct s_point
{
	int x; // x-coordinate of the point
	int y; // y-coordinate of the point
} t_point;

#endif
