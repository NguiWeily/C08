#include "ft_point.h"

// Include the necessary header file

// Function to set the values of a point
void set_point(t_point *point)
{
	point->x = 42; // Set the x-coordinate of the point to 42
	point->y = 21; // Set the y-coordinate of the point to 21
}

int main(void)
{
	t_point point; // Declare a variable of type t_point

	set_point(&point); // Call the set_point function, passing the address of the point variable

	return (0); // Return 0 to indicate successful program execution
}

