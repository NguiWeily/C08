/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stock_str.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 19:08:09 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 19:08:11 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STOCK_STR_H
# define FT_STOCK_STR_H

// Header guard to prevent multiple inclusions of the header file

// Define the structure type for representing a stock string
typedef struct s_stock_str
{
	int size;      // Size of the string
	char *str;     // Pointer to the string
	char *copy;    // Pointer to a copy of the string
} t_stock_str;

#endif

