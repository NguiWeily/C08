/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab_main.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 19:08:38 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 19:11:07 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include "ft_stock_str.h"

// Include necessary headers

// Function to calculate the length of a string
int ft_str_length(char *str)
{
	int index;

	// Declare the index variable

	index = 0;

	// Loop until the end of the string
	while (str[index])
		index++;

	// Return the length of the string
	return (index);
}

// Function to duplicate a string
char *ft_strdup(char *src)
{
	int index;
	char *dest;
	char *d;

	// Declare variables for index, destination string, and a temporary pointer

	index = 0;

	// Allocate memory for the duplicated string
	dest = (char *)malloc(ft_str_length(src) * sizeof(char) + 1);
	d = dest;

	// Return NULL if memory allocation fails
	if (!d)
		return (0);

	// Loop until the end of the source string
	while (src[index])
	{
		// Copy characters from source to destination
		dest[index] = src[index];
		index++;
	}

	// Add null terminator to the destination string
	dest[index] = '\0';

	// Return the duplicated string
	return (dest);
}

// Function to convert an array of strings to an array of stock strings
struct s_stock_str *ft_strs_to_tab(int ac, char **av)
{
	int index;
	struct s_stock_str *array;
	struct s_stock_str *d;

	// Declare variables for the index, array of stock strings, and a pointer for copying

	// Allocate memory for the array of stock strings
	array = malloc((ac + 1) * sizeof(struct s_stock_str));

	// Set the pointer 'd' to the start of the array
	d = array;

	// Return NULL if memory allocation fails
	if (!d)
		return (NULL);

	index = 0;

	// Loop through the input array of strings
	while (index < ac)
	{
		// Set the size of the stock string
		array[index].size = ft_str_length(av[index]);

		// Set the string pointer of the stock string
		array[index].str = av[index];

		// Set the copy pointer of the stock string by duplicating the string
		array[index].copy = ft_strdup(av[index]);

		index++;
	}

	// Set the string pointer of the last stock string to NULL
	array[index].str = 0;

	// Set the copy pointer of the last stock string to NULL
	array[index].copy = 0;

	// Return the array of stock strings
	return (array);
}

// Main function
int main(int argc, char **argv)
{
	int index;
	struct s_stock_str *structs;

	// Declare variables for the index and the array of stock strings

	// Convert command-line arguments to an array of stock strings
	structs = ft_strs_to_tab(argc, argv);

	index = 0;

	// Loop through the array of stock strings
	while (index < argc)
	{
		// Print the index
		printf("%d\n", index);

		// Print the original string and its address
		printf("\t| original : $%s$ @ %p\n", structs[index].str, structs[index].str);

		// Print the copied string and its address
		printf("\t|   copied : $%s$ @ %p\n", structs[index].copy, structs[index].copy);

		// Print the size of the string
		printf("\t|     size : %d\n", structs[index].size);

		index++;
	}

	// Return 0 to indicate successful execution
	return (0);
}
