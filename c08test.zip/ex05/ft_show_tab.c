/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 19:20:48 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 19:20:51 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "ft_stock_str.h"

// Include necessary headers

// Function to write a character to the standard output
void ft_putchar(char c)
{
	write(1, &c, 1);
}

// Function to write a string to the standard output
void ft_putstr(char *str)
{
	// Loop until the end of the string
	while (*str)
	{
		// Write each character to the standard output
		write(1, str, 1);
		str++;
	}
}

// Function to write an integer to the standard output
void ft_putnbr(int nb)
{
	// Handle the special case of the minimum integer value
	if (nb == -2147483648)
	{
		// Write the '-' character to indicate a negative number
		ft_putchar('-');

		// Write the first digit of the absolute value
		ft_putchar('2');

		// Recursively call the function to handle the remaining digits
		ft_putnbr(147483648);
	}
	// Handle negative numbers
	else if (nb < 0)
	{
		// Write the '-' character to indicate a negative number
		ft_putchar('-');

		// Convert the number to its absolute value
		nb = -nb;

		// Recursively call the function to handle the absolute value
		ft_putnbr(nb);
	}
	// Handle numbers greater than 9
	else if (nb > 9)
	{
		// Recursively call the function to write the digits in reverse order
		ft_putnbr(nb / 10);
		ft_putnbr(nb % 10);
	}
	// Handle single-digit numbers
	else
		ft_putchar(nb + 48);
}

// Function to display the contents of an array of stock strings
void ft_show_tab(struct s_stock_str *par)
{
	int index;

	index = 0;

	// Loop through the array of stock strings until the end marker is reached
	while (par[index].str != 0)
	{
		// Display the original string
		ft_putstr(par[index].str);
		ft_putstr("\n");

		// Display the size of the string
		ft_putnbr(par[index].size);
		ft_putstr("\n");

		// Display the copied string
		ft_putstr(par[index].copy);
		ft_putstr("\n");

		index++;
	}
}
