/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stock_str.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/02 19:21:13 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 19:21:14 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STOCK_STR_H
# define FT_STOCK_STR_H

// Header guard to prevent multiple inclusion of the same header file

// Define a new data type called t_stock_str using a struct
typedef struct s_stock_str
{
	int size;     // Member variable to store the size of the string
	char *str;    // Member variable to store the original string
	char *copy;   // Member variable to store the copied string
} t_stock_str;

#endif
